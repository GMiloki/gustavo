from django.shortcuts import render
from django.http import HttpResponse

def pagina1(request):
    return render(request,"login.html")

def pagina2(request):
    return render(request,"index.html")

def pagina3(request):
    return render(request,"PastorAlemao.html")

def pagina4(request):
    return render(request,"PittBull.html")

def pagina5(request):
    return render(request,"CadastroCachorro.html")

def pagina6(request):
    return render(request,"Urls_das_paginas.html")

